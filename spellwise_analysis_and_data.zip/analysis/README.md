# Analysis

`analyze_spellwise.py` reproduces all statistics, tables and figures of
Chapter 5 of the thesis from the data in `../data`.

```
pip install -r analysis/requirements.txt
python analysis/analyze_spellwise.py
```

Results are written to `analysis/output/`: `SpellWise_Results.xlsx` (one sheet
per analysis, plus APA-formatted sentences) and the figures in
`analysis/output/figures/`.
