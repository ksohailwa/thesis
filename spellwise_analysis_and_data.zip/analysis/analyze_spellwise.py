"""
SpellWise thesis: complete statistical analysis and figures.

Reproduces all results reported in Chapter 5 of the master's thesis
"Impact of AI-supported Cognitive Offloading on Orthographic and Semantic
Vocabulary Acquisition in English as a Second Language" (Khan Sohail,
University of Duisburg-Essen, 2026).

Inputs (folder ../data, see ../data/README.md)
  items.csv              one row per participant x target word (18 x 10)
  participants.csv       one row per participant: group, ratings, questionnaire
  flow_counts.csv        participant flow (Figure 4.2)

Outputs (written to ./output)
  SpellWise_Results.xlsx one sheet per analysis + APA-formatted sentences
  figures/*.png          learning curve, effort/difficulty, participant flow

Analyses
  Sample   retention interval, break length, group sizes
  RQ1      linear mixed model  similarity ~ condition * time + (1|participant) + (1|word),
           REML, likelihood-ratio test of the interaction; perfect vs imperfect
           spellings; paired t-test pre-test vs delayed test, conditions pooled
  RQ2      two-sided paired t-test, delayed meaning accuracy, active vs direct
  RQ3      two-sided paired t-tests on mental effort and perceived difficulty;
           Spearman correlations of effort with immediate and delayed spelling
           similarity (95% CI via Fisher's r-to-z transformation)
  Offloading  descriptives of the five items and their mean score, Cronbach's alpha

Run from the repository root:  python analysis/analyze_spellwise.py
Requires: pandas, numpy, scipy, statsmodels, matplotlib, openpyxl
"""
import os
import sys
import warnings

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import statsmodels.formula.api as smf
from scipy import stats

warnings.filterwarnings("ignore")

# ---------------------------------------------------------------------------
# 0. Input files
# ---------------------------------------------------------------------------
HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "..", "data")
OUT = os.path.join(HERE, "output")
os.makedirs(os.path.join(OUT, "figures"), exist_ok=True)
IN_NOTEBOOK = "ipykernel" in sys.modules

items = pd.read_csv(os.path.join(DATA, "items.csv"))
people = pd.read_csv(os.path.join(DATA, "participants.csv"))
FLOW = pd.read_csv(os.path.join(DATA, "flow_counts.csv"))

# Internal names: condition "treatment" = active correction, "control" = direct correction
items["condition"] = items["condition"].map({"active": "treatment", "direct": "control"})
items = items.rename(columns={"participant": "participantId"})
people = people.rename(columns={"participant": "participantId"})

ITEMS = items.copy()
D = items.rename(columns={"baselineExact": "baselineExactAccuracy",
                          "immediateExact": "immediateExactAccuracy",
                          "delayedExact": "delayedExactAccuracy",
                          "delayedSemantic": "delayedSemanticAccuracy"})
PROT = people
# One row per participant with ratings and questionnaire values
P = people.set_index("participantId")

RESULTS = {}   # sheet name -> DataFrame
APA = []       # (analysis, sentence)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def p_apa(p):
    """p value in APA style: no leading zero, 'p < .001' for small values."""
    return "p < .001" if p < .001 else "p = " + f"{p:.3f}".lstrip("0")


def r_apa(x):
    """Correlation without leading zero, with a proper minus sign."""
    s = f"{abs(x):.2f}".lstrip("0")
    return ("−" if x < 0 else "") + s


def f2(x, d=2):
    """Number with a proper minus sign."""
    return ("−" if x < 0 else "") + f"{abs(x):.{d}f}"


def paired_t(a, b):
    """Two-sided paired t-test of a vs b with d_z and 95% CI of the mean difference."""
    x = pd.concat([a, b], axis=1).dropna()
    x.columns = ["a", "b"]
    diff = x.a - x.b
    n = len(diff)
    t = stats.ttest_rel(x.a, x.b)
    half = stats.t.ppf(0.975, n - 1) * diff.std(ddof=1) / np.sqrt(n)
    return dict(n=n, M_a=x.a.mean(), SD_a=x.a.std(ddof=1), M_b=x.b.mean(), SD_b=x.b.std(ddof=1),
                M_diff=diff.mean(), SD_diff=diff.std(ddof=1),
                CI_low=diff.mean() - half, CI_high=diff.mean() + half,
                t=t.statistic, df=n - 1, p=t.pvalue, dz=diff.mean() / diff.std(ddof=1))


def t_sentence(r, label):
    return (f"{label}: M = {f2(r['M_a'])} (SD = {f2(r['SD_a'])}) vs. M = {f2(r['M_b'])} "
            f"(SD = {f2(r['SD_b'])}), t({r['df']}) = {f2(r['t'])}, {p_apa(r['p'])}, "
            f"d_z = {f2(r['dz'])}, 95% CI of the difference [{f2(r['CI_low'])}, {f2(r['CI_high'])}].")


def spearman(x, y):
    """Spearman rho with a 95% CI from the Fisher z transformation."""
    rho, p = stats.spearmanr(x, y)
    z, se = np.arctanh(rho), 1 / np.sqrt(len(x) - 3)
    return dict(rho=rho, CI_low=np.tanh(z - 1.96 * se), CI_high=np.tanh(z + 1.96 * se), p=p, n=len(x))


def cronbach_alpha(df):
    df = df.dropna()
    k = df.shape[1]
    return k / (k - 1) * (1 - df.var(ddof=1).sum() / df.sum(axis=1).var(ddof=1))


# ---------------------------------------------------------------------------
# Sample and protocol (Section 5.1)
# ---------------------------------------------------------------------------
sample = pd.DataFrame([
    ("Participants analysed", len(P)),
    ("Started with active correction", int(P.treatmentFirst.sum())),
    ("Started with direct correction", int((1 - P.treatmentFirst).sum())),
    ("Active correction on Story A", int((D[D.condition == "treatment"].drop_duplicates("participantId").story == "A").sum())),
    ("Active correction on Story B", int((D[D.condition == "treatment"].drop_duplicates("participantId").story == "B").sum())),
    ("Missing pre-test responses", int(D.baselineSimilarity.isna().sum())),
    ("Retention interval, median (h)", PROT.retentionHours.median()),
    ("Retention interval, min (h)", PROT.retentionHours.min()),
    ("Retention interval, max (h)", PROT.retentionHours.max()),
    ("Break between stories, median (min)", PROT.breakMinutes.median()),
    ("Break shorter than 5 min (participants)", int((PROT.breakMinutes < 5).sum())),
    ("Delayed responses without stored text", int((D.delayedScoreSource == "platform_unverifiable").sum())),
], columns=["Measure", "Value"])
RESULTS["0_Sample"] = sample


# ---------------------------------------------------------------------------
# RQ1: linear mixed model, pre-test vs delayed test
# ---------------------------------------------------------------------------
base_cols = ["participantId", "word", "condition"]
long = pd.concat([
    D[base_cols].assign(time="pre", similarity=D.baselineSimilarity, exact=D.baselineExactAccuracy),
    D[base_cols].assign(time="delay", similarity=D.delayedSimilarity, exact=D.delayedExactAccuracy),
], ignore_index=True).dropna(subset=["similarity"]).reset_index(drop=True)
long["condition"] = pd.Categorical(long.condition, ["control", "treatment"])
long["time"] = pd.Categorical(long.time, ["pre", "delay"])

FULL = "similarity ~ C(condition, Treatment('control')) * C(time, Treatment('pre'))"
REDUCED = "similarity ~ C(condition, Treatment('control')) + C(time, Treatment('pre'))"


def fit_lmm(formula, reml):
    # crossed random intercepts for participants and words (one dummy group, variance components)
    model = smf.mixedlm(formula, long, groups=np.ones(len(long)), re_formula="0",
                        vc_formula={"participant": "0 + C(participantId)", "word": "0 + C(word)"})
    return model.fit(reml=reml, method="lbfgs", maxiter=500)


m = fit_lmm(FULL, reml=True)
labels = {
    "Intercept": "Intercept (direct, pre-test)",
    "C(condition, Treatment('control'))[T.treatment]": "Condition (active)",
    "C(time, Treatment('pre'))[T.delay]": "Time (delayed)",
    "C(condition, Treatment('control'))[T.treatment]:C(time, Treatment('pre'))[T.delay]": "Condition x time",
}
fe = m.fe_params.index
ci = m.conf_int()
lmm = pd.DataFrame({"Effect": [labels[k] for k in fe], "b": m.fe_params.values, "SE": m.bse_fe.values,
                    "z": m.tvalues[fe].values, "p": m.pvalues[fe].values,
                    "CI_low": ci.loc[fe, 0].values, "CI_high": ci.loc[fe, 1].values})
lr = 2 * (fit_lmm(FULL, reml=False).llf - fit_lmm(REDUCED, reml=False).llf)
p_lr = stats.chi2.sf(lr, 1)
extra = pd.DataFrame({"Effect": ["Variance: participant", "Variance: word", "Variance: residual",
                                 "LRT interaction chi2(1)", "LRT p", "Observations", "Participants", "Words"],
                      "b": [m.vcomp[0], m.vcomp[1], m.scale, lr, p_lr,
                            len(long), long.participantId.nunique(), long.word.nunique()]})
RESULTS["1_RQ1_LMM"] = pd.concat([lmm, extra], ignore_index=True)

ia = lmm[lmm.Effect == "Condition x time"].iloc[0]
APA.append(("RQ1 mixed model",
            f"The condition × time interaction was not significant, b = {f2(ia.b, 3)}, SE = {ia.SE:.3f}, "
            f"z = {f2(ia.z)}, {p_apa(ia.p)}, 95% CI [{f2(ia.CI_low, 3)}, {f2(ia.CI_high, 3)}]; "
            f"likelihood-ratio test χ²(1) = {lr:.2f}, {p_apa(p_lr)}."
            if ia.p >= .05 else
            f"The condition × time interaction was significant, b = {f2(ia.b, 3)}, {p_apa(ia.p)}."))

# Perfect vs imperfect spellings (Table 5.1)
rows = []
for (cond, tm), g in long.groupby(["condition", "time"], observed=True):
    perfect = g.similarity >= 1 - 1e-9
    dist = 1 - g.loc[~perfect, "similarity"]
    rows.append({"Condition": "Active" if cond == "treatment" else "Direct",
                 "Time": "Pre-test" if tm == "pre" else "Delayed",
                 "N words": len(g), "N perfect": int(perfect.sum()), "% perfect": 100 * perfect.mean(),
                 "N imperfect": int((~perfect).sum()),
                 "Distance imperfect M": dist.mean(), "Distance imperfect SD": dist.std(ddof=1)})
RESULTS["1b_Perfect_imperfect"] = pd.DataFrame(rows)

# Pre vs delayed, conditions pooled (participant means over all ten words)
rows = []
for lab, pre, post in [("Spelling similarity", "baselineSimilarity", "delayedSimilarity"),
                       ("Perfect spellings (proportion)", "baselineExactAccuracy", "delayedExactAccuracy")]:
    pm = D.groupby("participantId")[[pre, post]].mean()
    r = paired_t(pm[post], pm[pre])
    r["Outcome"] = lab
    rows.append(r)
    APA.append((f"Pre vs delayed ({lab})", t_sentence(r, f"{lab}, delayed vs. pre-test")))
RESULTS["1c_Pre_vs_delayed"] = (pd.DataFrame(rows)
                                .rename(columns={"M_a": "M_delayed", "SD_a": "SD_delayed", "M_b": "M_pre", "SD_b": "SD_pre"}))


# ---------------------------------------------------------------------------
# RQ2: delayed meaning accuracy
# ---------------------------------------------------------------------------
cm = D.groupby(["participantId", "condition"]).delayedSemanticAccuracy.mean().unstack()
r = paired_t(cm.treatment, cm.control)
RESULTS["2_RQ2_Meaning"] = pd.DataFrame([r]).rename(
    columns={"M_a": "M_active", "SD_a": "SD_active", "M_b": "M_direct", "SD_b": "SD_direct"})
APA.append(("RQ2 meaning", t_sentence(r, "Delayed meaning accuracy, active vs. direct")))


# ---------------------------------------------------------------------------
# RQ3: effort and difficulty by condition, and effort vs retention
# ---------------------------------------------------------------------------
rows = []
for lab, a_col, b_col in [("Mental effort (1-9)", "avgMentalEffortIntervention", "avgMentalEffortControl"),
                          ("Perceived difficulty (1-9)", "difficultyTreatment", "difficultyControl")]:
    r = paired_t(P[a_col], P[b_col])
    r["Outcome"] = lab
    rows.append(r)
    APA.append((f"RQ3 {lab}", t_sentence(r, f"{lab}, active vs. direct")))
RESULTS["3_RQ3_Effort_ttests"] = pd.DataFrame(rows).rename(
    columns={"M_a": "M_active", "SD_a": "SD_active", "M_b": "M_direct", "SD_b": "SD_direct"})

means = D.groupby(["participantId", "condition"])[["immediateSimilarity", "delayedSimilarity"]].mean()
effort_col = {"treatment": "avgMentalEffortIntervention", "control": "avgMentalEffortControl"}
rows = []
for cond, name in [("treatment", "Active"), ("control", "Direct")]:
    d = means.xs(cond, level="condition").join(P[effort_col[cond]])
    for col, lab in [("immediateSimilarity", "Effort - immediate retention"),
                     ("delayedSimilarity", "Effort - delayed retention")]:
        rows.append({"Variables": lab, "Condition": name, **spearman(d[effort_col[cond]], d[col])})
corr = pd.DataFrame(rows)
RESULTS["3b_RQ3_Correlations"] = corr

# Relationship between mental effort and perceived difficulty within each condition
rows = [{"Condition": name, **spearman(P[e], P[d])}
        for name, e, d in [("Active", "avgMentalEffortIntervention", "difficultyTreatment"),
                           ("Direct", "avgMentalEffortControl", "difficultyControl")]]
RESULTS["3c_Effort_difficulty_corr"] = pd.DataFrame(rows)
APA.append(("RQ3 correlations",
            "Spearman correlations between effort and retention: " + "; ".join(
                f"{r.Variables.lower()}, {r.Condition.lower()}: ρ = {r_apa(r.rho)}, "
                f"95% CI [{r_apa(r.CI_low)}, {r_apa(r.CI_high)}], {p_apa(r.p)}" for r in corr.itertuples()) + "."))


# ---------------------------------------------------------------------------
# Offloading tendencies (descriptive)
# ---------------------------------------------------------------------------
item_cols = [f"offloadingItem{k}" for k in range(1, 6)]
if all(c in P.columns for c in item_cols):
    score = P[item_cols].mean(axis=1)
    rows = [{"Item": f"Item {k}", "n": int(P[c].notna().sum()), "M": P[c].mean(), "SD": P[c].std(ddof=1),
             "Mdn": P[c].median(), "Min": P[c].min(), "Max": P[c].max()} for k, c in enumerate(item_cols, 1)]
    rows.append({"Item": "Score (mean of 5 items)", "n": int(score.notna().sum()), "M": score.mean(),
                 "SD": score.std(ddof=1), "Mdn": score.median(), "Min": score.min(), "Max": score.max()})
    alpha = cronbach_alpha(P[item_cols])
    RESULTS["4_Offloading"] = pd.concat(
        [pd.DataFrame(rows), pd.DataFrame([{"Item": "Cronbach's alpha", "M": alpha}])], ignore_index=True)
    APA.append(("Offloading",
                f"The offloading score was M = {score.mean():.2f} (SD = {score.std(ddof=1):.2f}, range "
                f"{score.min():.1f}–{score.max():.1f}), Cronbach's α = {r_apa(alpha)}."))
else:
    print("NOTE: offloadingItem1-5 not found in the dataset; offloading skipped.")


# ---------------------------------------------------------------------------
# Save results
# ---------------------------------------------------------------------------
RESULTS["APA_text"] = pd.DataFrame(APA, columns=["Analysis", "Sentence (APA 7)"])
OUT_XLSX = os.path.join(OUT, "SpellWise_Results.xlsx")
with pd.ExcelWriter(OUT_XLSX, engine="openpyxl") as xw:
    for name, df in RESULTS.items():
        df.round(6).to_excel(xw, sheet_name=name[:31], index=False)
    for ws in xw.sheets.values():
        for col in ws.columns:
            width = max(len(str(c.value)) for c in col[:8]) + 2
            ws.column_dimensions[col[0].column_letter].width = min(70, max(10, width))


# ---------------------------------------------------------------------------
# Figures
# ---------------------------------------------------------------------------
ACTIVE, DIRECT, GREY = "#D55E00", "#0072B2", "#9aa0a6"   # colour-blind safe
plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.edgecolor": "#666", "axes.titleweight": "bold", "axes.titlesize": 11,
                     "figure.dpi": 110, "savefig.dpi": 300, "savefig.bbox": "tight"})
saved = []


def save(fig, name):
    path = os.path.join(OUT, "figures", f"{name}.png")
    fig.savefig(path)
    plt.close(fig)
    saved.append(path)
    if IN_NOTEBOOK:
        from IPython.display import display, Image
        display(Image(filename=path, width=900))


def mean_ci(x):
    x = np.asarray(x, float)
    x = x[~np.isnan(x)]
    half = stats.t.ppf(0.975, len(x) - 1) * x.std(ddof=1) / np.sqrt(len(x))
    return x.mean(), x.mean() - half, x.mean() + half


# Figure 5.1: spelling across the four occurrences
fig, axes = plt.subplots(1, 2, figsize=(10, 3.8))
for ax, (suffix, ylabel) in zip(axes, [("Similarity", "Mean spelling similarity"),
                                       ("Exact", "Proportion of perfect spellings")]):
    cols = [f"baseline{suffix}", f"occ2{suffix}", f"immediate{suffix}", f"delayed{suffix}"]
    for cond, colour, name, shift in [("control", DIRECT, "Direct", -0.05), ("treatment", ACTIVE, "Active", 0.05)]:
        pm = ITEMS[ITEMS.condition == cond].groupby("participantId")[cols].mean()
        ax.errorbar(np.arange(4) + shift, pm.mean(), yerr=1.96 * pm.sem(), color=colour, marker="o",
                    lw=2, capsize=3, label=name)
    ax.axvspan(2.5, 3.5, color="#eee", zorder=0)
    ax.text(3, ax.get_ylim()[0], "≥12 h later", ha="center", va="bottom", fontsize=8, color="#555")
    ax.set_xticks(range(4), ["1st\n(pre-test)", "2nd", "3rd\n(immediate)", "Delayed\ntest"])
    ax.set_ylabel(ylabel)
    ax.set_xlim(-0.3, 3.5)
    ax.grid(axis="y", alpha=0.25)
    ax.legend(loc="upper left", frameon=False)
save(fig, "02_learning_curve")

# Figure 5.2: effort and difficulty per participant
fig, axes = plt.subplots(1, 2, figsize=(7.5, 3.8))
for ax, (direct_col, active_col, title) in zip(axes, [
        ("avgMentalEffortControl", "avgMentalEffortIntervention", "Mental effort (1–9)"),
        ("difficultyControl", "difficultyTreatment", "Perceived difficulty (1–9)")]):
    w = P[[direct_col, active_col]].dropna()
    for _, row in w.iterrows():
        ax.plot([0, 1], [row[direct_col], row[active_col]], "-o", color=GREY, alpha=0.5, ms=3)
    for x, col, colour in [(0, direct_col, DIRECT), (1, active_col, ACTIVE)]:
        mm, lo, hi = mean_ci(w[col])
        ax.errorbar(x + (0.12 if x else -0.12), mm, yerr=[[mm - lo], [hi - mm]], fmt="D",
                    color=colour, ms=7, capsize=4, lw=2)
    p = stats.ttest_rel(w[active_col], w[direct_col]).pvalue
    ax.set_title(f"{title}\n{p_apa(p)}")
    ax.set_xticks([0, 1], ["Direct", "Active"])
    ax.set_xlim(-0.4, 1.4)
    ax.grid(axis="y", alpha=0.25)
save(fig, "04_effort_difficulty")

# Figure 4.x: participant flow
try:
    FC = FLOW.set_index("Stage")
    n = lambda stage: int(FC.loc[stage, "Total"])
    fig, ax = plt.subplots(figsize=(8.5, 4.6))
    ax.axis("off")
    ax.set_xlim(0, 10)
    ax.set_ylim(-0.6, 6.2)

    def box(x, y, w, h, text, fc="#f4f4f4", ec="#666"):
        ax.add_patch(plt.Rectangle((x, y), w, h, fc=fc, ec=ec, lw=1.2))
        ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=9.5)

    arrow = dict(arrowstyle="-|>", color="#666", lw=1.2)
    box(0.2, 4.8, 4.2, 1.1, f"Accounts registered\nn = {n('All non-test accounts')}")
    box(0.2, 0.3, 4.2, 1.2, f"Completed both sessions\n(analysed)\nn = {n('Completed (analysed)')}",
        fc="#fbe6d6", ec=ACTIVE)
    ax.annotate("", xy=(2.3, 1.5), xytext=(2.3, 4.8), arrowprops=arrow)
    for y, stage, label in [(3.65, "Registered, never started", "Never started"),
                            (2.45, "Left during Session 1", "Left during Session 1"),
                            (1.25, "Finished Session 1, no delayed test", "Finished Session 1,\nno delayed test")]:
        box(5.6, y - 0.05, 4.2, 1.1, f"Not analysed: {label}\nn = {n(stage)}")
        ax.annotate("", xy=(5.6, y + 0.5), xytext=(2.3, y + 0.5), arrowprops=arrow)
    save(fig, "10_participant_flow")
except Exception as ex:
    print("Participant-flow figure skipped:", ex)


# ---------------------------------------------------------------------------
# Print summary
# ---------------------------------------------------------------------------
pd.set_option("display.width", 200)
pd.set_option("display.max_colwidth", 200)
for name, df in RESULTS.items():
    if name != "APA_text":
        print(f"\n== {name}")
        print(df.round(3).to_string(index=False))
print("\n== APA sentences")
for analysis, sentence in APA:
    print(f"\n[{analysis}]\n{sentence}")
print("\nSaved", OUT_XLSX, "and", *saved)
