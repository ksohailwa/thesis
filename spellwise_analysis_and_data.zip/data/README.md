# SpellWise study data

Anonymised data of the 18 participants who completed both sessions of the
SpellWise study (master's thesis, Khan Sohail, University of Duisburg-Essen,
2026). The data reproduce all results in Chapter 5 of the thesis with
`analysis/analyze_spellwise.py`.

## Anonymisation
- Participants are labelled `P01`–`P18`. Platform account IDs, access codes,
  names, e-mail addresses and timestamps have been removed.
- Retention interval and break length are rounded to 0.1 hours / minutes.
- Typed responses contain only the participants' spelling attempts of the
  target words.

## Files

### `items.csv` (180 rows: 18 participants × 10 target words)
| Column | Description |
|---|---|
| `participant` | Participant label (P01–P18) |
| `word` | Target word |
| `story` | Story containing the word (A or B) |
| `condition` | Correction procedure for this story: `active` or `direct` |
| `treatmentFirst` | 1 if the participant learned under active correction first |
| `storyFirst` | 1 if this word's story was the first story in Session 1 |
| `baselineResponse`, `occ2Response`, `immediateResponse`, `delayedResponse` | Typed spelling at the 1st, 2nd and 3rd occurrence and in the delayed test (first attempt) |
| `…Similarity` | Spelling similarity: 1 − Levenshtein distance / length of the longer string (case-insensitive, trimmed); 0–1 |
| `…Exact` | 1 if the spelling matches the target exactly |
| `delayedSemantic` | 1 if the correct meaning was chosen in the delayed test (4 options) |
| `delayedScoreSource` | `recomputed` = scored from the stored text; `platform_unverifiable` = no text stored, platform score used |

The 1st occurrence is the pre-test, the 3rd occurrence the immediate
retention measure. One pre-test response is missing (logging error).

### `participants.csv` (18 rows)
| Column | Description |
|---|---|
| `participant` | Participant label (P01–P18) |
| `group` | Counterbalancing group (story with active correction, condition order) |
| `treatmentStory` | Story learned under active correction (A or B) |
| `firstStory` | Story read first in Session 1 |
| `treatmentFirst` | 1 if active correction came first |
| `retentionHours` | Hours between the end of Session 1 and the delayed test |
| `breakMinutes` | Minutes between the two stories |
| `avgMentalEffortIntervention`, `avgMentalEffortControl` | Mean Paas mental effort (1–9) under active / direct correction |
| `difficultyTreatment`, `difficultyControl` | Mean perceived difficulty (1–9) under active / direct correction |
| `offloadingItem1`–`offloadingItem5` | Offloading questionnaire items (1 = strongly disagree, 6 = strongly agree) |
| `offloadingScore` | Mean of the five items |

### `flow_counts.csv`, `flow_by_sequence.csv`
Participant flow from registration to analysis (Figure 4.2), in total and by
counterbalancing sequence.
